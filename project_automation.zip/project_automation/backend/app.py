from flask import Flask, render_template, request
import os

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Define allowed extensions (optional, but recommended)
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'txt'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return "No file part", 400
    file = request.files["file"]
    if file.filename == "":
        return "No selected file", 400
    if file and allowed_file(file.filename):
        file_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(file_path)
        return f"File uploaded successfully: {file.filename}", 200
    return "Invalid file type", 400

@app.route("/create-jira")
def create_jira():
    return "Jira tickets created successfully!"

@app.route("/create-github")
def create_github():
    return "GitHub repository structured successfully!"

@app.route("/generate-tests")
def generate_tests():
    return "Test cases generated successfully!"

if __name__ == "__main__":
    app.run(debug=True)
