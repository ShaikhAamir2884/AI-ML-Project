from flask import Flask, request, jsonify, render_template
from scraper import scrape_data
from emailer import send_emails
from analytics import track_open, get_stats

app = Flask(__name__)

@app.route('/scrape', methods=['POST'])
def scrape():
    data = request.get_json()
    industry = data['industry']
    location = data['location']
    scraped = scrape_data(industry, location)
    return jsonify({'message': f"Scraped {len(scraped)} leads successfully."})

@app.route('/send-emails')
def emails():
    count = send_emails()
    return jsonify({'message': f"Sent {count} emails."})

@app.route('/track/<id>.png')
def track(id):
    track_open(id)
    return ('', 204)

@app.route('/analytics')
def analytics():
    stats = get_stats()
    return jsonify(stats)

if __name__ == '__main__':
    app.run(debug=True)
