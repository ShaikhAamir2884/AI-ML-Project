def send_emails():
    # Simulate sending 2 emails
    return 2
