def scrape_data(industry, location):
    # Simulated scraped data
    leads = [
        {'company': 'ABC Corp', 'email': 'abc@example.com', 'industry': industry, 'location': location},
        {'company': 'XYZ Ltd', 'email': 'xyz@example.com', 'industry': industry, 'location': location}
    ]
    return leads
