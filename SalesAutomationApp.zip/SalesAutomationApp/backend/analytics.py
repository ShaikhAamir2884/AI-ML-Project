open_log = []

def track_open(id):
    open_log.append(id)

def get_stats():
    return {
        'opens': len(open_log),
        'hot_leads': len(set(open_log))
    }
