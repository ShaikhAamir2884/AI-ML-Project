document.getElementById('icpForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const data = Object.fromEntries(form.entries());
  
    document.getElementById('status').textContent = 'Scraping...';
  
    const res = await fetch('http://localhost:5000/scrape', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
  
    const result = await res.json();
    document.getElementById('status').textContent = result.message;
  });
  